package introducao.avaliacao1;

import java.util.ArrayList;
import java.util.concurrent.ForkJoinWorkerThread;

public class FaseDaObra {
    private String nome;
    private Engenheiro encarregado;
    private ArrayList<ItemDeConstrucao> listaItens = new ArrayList<>();
    private ArrayList<Construtor> listaConstrutores = new ArrayList<>();
    

    public ArrayList<Construtor> getListaConstrutores() {
        return listaConstrutores;
    }

    public void setListaConstrutores(ArrayList<Construtor> listaConstrutores) {
        this.listaConstrutores = listaConstrutores;
    }

    public ArrayList<ItemDeConstrucao> getListaItens() {
        return listaItens;
    }

    public void setListaItens(ArrayList<ItemDeConstrucao> listaItens) {
        this.listaItens = listaItens;
    }

    public Engenheiro getEncarregado() {
        return encarregado;
    }

    public void setEncarregado(Engenheiro encarregado) {
        this.encarregado = encarregado;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    
    /*Calcular e retornar o valor total da fase da obra considerando os itens de construção
     (quantidade e preço do material de construção) e o salário do encarregado e dos construtores */
    }
    public float calcularValorDaFaseDaObra(){
        float soma1 = 0;
        float soma2= 0;
        float soma3 = 0;
                
        for(var umConstrutor : getListaConstrutores()){
            soma1 = soma1 + umConstrutor.getSalario();
        }
        for(var umItem : getListaItens()){
                soma2 = soma2 + (umItem.getQuantidade() * umItem.getProduto().getPreco());
        }
        soma3 = getEncarregado().getSalario();
          
          
        return soma1 + soma2 + soma3;
                
    }
}
        
        
            
                
            
            
            
            
        
        

    

            

            
            
    
        
        
    

