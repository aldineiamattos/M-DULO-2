package introducao.avaliacao1;

import java.util.ArrayList;

public class Obra {
    private ArrayList<FaseDaObra> listafases = new ArrayList<>();

    public ArrayList<FaseDaObra> getListafases() {
        return listafases;
    }

    public void setListafases(ArrayList<FaseDaObra> listafases) {
        this.listafases = listafases;
    
    /*Construir um texto contendo todos os dados das Fases da Obra,os Itens de construção e os materiais, 
    além dos dados do encarregado e dos construtores*/  
    }
    public String listarDadosDaObra(){
        StringBuilder montadorDeStrings = new StringBuilder();
        for(var umaFase : this.getListafases()){
            montadorDeStrings.append("\nNome Fase: " + umaFase.getNome());
            montadorDeStrings.append("\n Nome Encarregado: " + umaFase.getEncarregado().getNome());
            montadorDeStrings.append("\nNumero: " + umaFase.getEncarregado().getNumero());
            montadorDeStrings.append("\nSalario: " + umaFase.getEncarregado().getSalario());
            montadorDeStrings.append("\nFormação: " + umaFase.getEncarregado().getFormacao());
            for (var umConstrutor : umaFase.getListaConstrutores()){
                montadorDeStrings.append("\nNome Construtor: " + umConstrutor.getNome());
                montadorDeStrings.append("\nNumero: " + umConstrutor.getNumero());
                montadorDeStrings.append("\nSalario: " + umConstrutor.getSalario());
            }
            for(var umItem : umaFase.getListaItens()){
                    montadorDeStrings.append("\nQuantidade Item: " + umItem.getQuantidade());
                    montadorDeStrings.append("\nNome Prod: " + umItem.getProduto().getNome());
                    montadorDeStrings.append("\nPreço Prod: " + umItem.getProduto().getPreco());
                
                }
        }
        return montadorDeStrings.toString(); 

    /*Calcular e retornar o valor total da obra somando o valor total das fases da obra.*/
    }
    public float calcularValorTotalDaObra(){
        float somaA=0;    
        float somaB=0;
        float somaC=0;
                
        for(var umaFase : getListafases()){
            somaA = somaA + umaFase.getEncarregado().getSalario();
            for(var umConstrutor : umaFase.getListaConstrutores()){
                somaB = somaB + umConstrutor.getSalario();
            }    
            for(var umItem : umaFase.getListaItens()){
                somaC = somaC + (umItem.getQuantidade() * umItem.getProduto().getPreco());
                
                }
            }
        return somaA + somaB + somaC; 
                            
    } 
}         
            




            
        

        

    
    
                

            
    

       


    
        
     
        
     
        

     
   
            











        
                    

    

