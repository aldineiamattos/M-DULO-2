package introducao.avaliacao20;

public class Formacao {

    private String nome;
    private int anoConclusao;
    
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public int getAnoConclusao() {
        return anoConclusao;
    }
    public void setAnoConclusao(int anoConclusao) {
        this.anoConclusao = anoConclusao;
    }

    
    
}

    

